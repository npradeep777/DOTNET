﻿using GroceryStore.Services.Models;
using GroceryStore.Services.Services;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GroceryStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private readonly ICustomerService _customerService;

        #region CustomerController constructor

        public CustomersController(ICustomerService customerService)
        {
            _customerService = customerService;
        }

        #endregion

        #region Customer API All CRUD operations - POST, GET, PUT, DELETE

        //Get All Customers
        [HttpGet]
        public async Task<IEnumerable<Customer>> GetCustomers()
        {
            return await _customerService.GetAllAsync();
        }

        //Get Customer by Id
        [HttpGet("{id}")]
        public async Task<ActionResult<Customer>> GetCustomers(int id)
        {
            return await _customerService.GetAsync(id);
        }

        //Create new customer
        [HttpPost]
        public async Task<ActionResult<Customer>> PostCustomer([FromBody] Customer customer)
        {
            var newCustomer = await _customerService.CreateAsync(customer);
            return CreatedAtAction(nameof(GetCustomers), new { id = newCustomer.Id }, newCustomer);
        }

        //Update existing customer
        [HttpPut("{id}")]
        public async Task<ActionResult> PutCustomers(int id, [FromBody] Customer customer)
        {
            if(id != customer.Id)
            {
                return BadRequest();
            }

            await _customerService.UpdateAsync(customer);
            
            return NoContent();
        }

        //Delete customer by id
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var customerToDelete = await _customerService.GetAsync(id);
            if(customerToDelete != null)
            {
                await _customerService.DeleteAsync(customerToDelete.Id);
                return NoContent();
            }

            return NotFound();
        }

        #endregion
    }
}