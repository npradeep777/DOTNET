﻿using GroceryStore.Services.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GroceryStore.Services.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly GroceryStoreContext _dbContext;
        public CustomerRepository(GroceryStoreContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<Customer> Create(Customer customer)
        {
            _dbContext.Customers.Add(customer);
            await _dbContext.SaveChangesAsync();

            return customer;
        }

        public async Task<bool> Delete(int id)
        {
            var deleteCustomer = await _dbContext.Customers.FindAsync(id);
            _dbContext.Customers.Remove(deleteCustomer);
            return await _dbContext.SaveChangesAsync() > 0;
        }

        public async Task<IEnumerable<Customer>> Get()
        {
            return await _dbContext.Customers.ToListAsync();
        }

        public async Task<Customer> Get(int id)
        {
            return await _dbContext.Customers.FindAsync(id);
        }

        public async Task<bool> Update(Customer customer)
        {
            _dbContext.Entry(customer).State = EntityState.Modified;
            return await _dbContext.SaveChangesAsync() > 0;
        }
    }
}
