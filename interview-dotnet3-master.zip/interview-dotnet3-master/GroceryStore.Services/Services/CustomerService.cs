﻿using GroceryStore.Services.Models;
using GroceryStore.Services.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GroceryStore.Services.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;

        public CustomerService(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public async Task<Customer> CreateAsync(Customer customer)
        {
            var newCustomer = await _customerRepository.Create(customer);

            //Business logic if newCustomer created
            //Log Customer created details

            return newCustomer;
        }

        public async Task DeleteAsync(int id)
        {
            if(id != 0)
            {
                var customerDeleted = await _customerRepository.Delete(id);

                //Business logic if customer deleted
                //Log Customer deleted details
            }
        }

        public async Task<IEnumerable<Customer>> GetAllAsync()
        {
            var customers = await _customerRepository.Get();

            //Business logic to check and return customer details
            //Log Customer Get customer details

            return customers;
        }

        public async Task<Customer> GetAsync(int id)
        {
            if (id != 0)
            {
                var customer = await _customerRepository.Get(id);

                //Business logic to check and return customer detail
                //Log Customer Get customer detail

                return customer;
            }

            return null;
        }

        public async Task UpdateAsync(Customer customer)
        {
            var updated = await _customerRepository.Update(customer);

            //Business logic if Customer updated
            //Log Customer updated details
        }
    }
}
