﻿using Microsoft.EntityFrameworkCore;

namespace GroceryStore.Services.Models
{
    public class GroceryStoreContext : DbContext
    {
        public GroceryStoreContext(DbContextOptions<GroceryStoreContext> options)
            :base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<Customer> Customers { get; set; }
    }
}
