using Microsoft.VisualStudio.TestTools.UnitTesting;
using GroceryStore.Services.Repositories;
using GroceryStore.Services.Models;
using Moq;
using System.Threading.Tasks;
using GroceryStore.Services.Services;

namespace GroceryStore.Services.Tests
{
    [TestClass]
    public class CustomerServiceTests
    {
        private readonly CustomerService _customerService;
        private readonly Mock<ICustomerRepository> _customerRepositoryMock = new Mock<ICustomerRepository>();       

        public CustomerServiceTests()
        {
            _customerService = new CustomerService(_customerRepositoryMock.Object);
        }

        #region Test cases for Get Customer

        [TestMethod]
        public async Task Given_CustomerId_0_Verify_Customer_ShouldReturnNothing()
        {
            //Given I have a customer value as 0
            var customerId = 0;
            Customer customerMock = new Customer();
            _customerRepositoryMock.Setup(a => a.Get(customerId)).ReturnsAsync(customerMock);

            //When I pass customerId to the customer repository
            var customer = await _customerService.GetAsync(customerId);

            //Then I get customer as null
            Assert.IsNull(customer);
        }

        [TestMethod]
        public async Task Given_CustomerId_1_Verify_Should_ReturnCustomer()
        {
            //Given I have a customer value as 1
            var customerId = 1;
            Customer customerMock = new Customer() { Id = 1, Name = "Walmart 1" };
            _customerRepositoryMock.Setup(a => a.Get(customerId)).ReturnsAsync(customerMock);

            //When I pass customerId to the customer repository
            var customer = await _customerService.GetAsync(customerId);

            //Then I get valid customer record
            Assert.IsNotNull(customer);
        }

        [TestMethod]
        public async Task Given_CustomerId_2_Verify_Should_ReturnCustomer()
        {
            //Given I have a customer value as 2
            var customerId = 2;
            Customer customerMock = new Customer() { Id = 2, Name = "Walmart 2" };
            _customerRepositoryMock.Setup(a => a.Get(customerId)).ReturnsAsync(customerMock);

            //When I pass customerId to the customer repository
            var customer = await _customerService.GetAsync(customerId);

            //Then I get valid customer record
            Assert.IsNotNull(customer);
        }

        [TestMethod]
        public async Task Given_CustomerId_5_Verify_Should_ReturnCustomerDoesNotExist()
        {
            //Given I have a customer value as 5
            var customerId = 5;
            Customer customerMock = new Customer() { Id = 2, Name = "Walmart 2" };
            _customerRepositoryMock.Setup(a => a.Get(customerId)).ReturnsAsync(customerMock);

            //When I pass customerId to the customer repository
            var customer = await _customerService.GetAsync(customerId);

            //Then I get valid customer record
            Assert.AreNotEqual(5, customer.Id);
        }

        #endregion

        #region Test cases for Add new Customer

        [TestMethod]
        public async Task Given_CustomerDetails_Create_Customer()
        {
            //Given I have a customer value as 0
            Customer customerMock = new Customer() { Id = 0, Name = "Test creation" };
            _customerRepositoryMock.Setup(a => a.Create(customerMock)).ReturnsAsync(customerMock);

            //When I pass customerId to the customer repository
            var newCustomerResult = await _customerService.CreateAsync(customerMock);

            //Then I get customer as null
            Assert.IsNotNull(newCustomerResult);
        }

        //Similarly all the test cases for add with different test cases follows
        #endregion

        //Similarly all the test cases for update with different test cases follows

        //Similarly all the test cases for delete with different test cases follows

        //Similarly all the test cases for GetAll with different test cases follows
    }
}
